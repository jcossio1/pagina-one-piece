import csv

def crearCSV(lista,nombreCSV):
    with open('data/'+nombreCSV,mode='w',newline='',encoding='utf-8') as archivo_csv:
        writer=csv.writer(archivo_csv)
        writer.writerow(['NumeroOrden','Cliente','Costo'])
        writer.writerows(lista)
        
def empleadosCSV(lista,nombreCSV):
    with open('data/'+nombreCSV,mode='w',newline='',encoding='utf-8') as archivo_csv:
        writer=csv.writer(archivo_csv)
        writer.writerow(['Nombre','Cargo','Edad', 'Salario'])
        writer.writerows(lista)


def empleadosCSV(lista,nombreCSV):
    with open('data/'+nombreCSV,mode='w',newline='',encoding='utf-8') as archivo_csv:
        writer=csv.writer(archivo_csv)
        writer.writerow(['id','nombre','apellido','salario','deudas','reteFuente','correo','telefono','cargo'])
        writer.writerows(lista)